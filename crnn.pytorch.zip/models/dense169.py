import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable


class _DenseLayer(nn.Module):
    def __init__(self, n_input_features, bn_sz, growth_rate):
        super(_DenseLayer, self).__init__()
        block = nn.Sequential()
        block.add_module("batch_norm1", nn.BatchNorm2d(n_input_features) )
        block.add_module("relu1", nn.ReLU(inplace=True))
        block.add_module("conv1", nn.Conv2d(n_input_features, bn_sz * growth_rate,
                                            1, stride=1, bias=False))
        # 1X1 convolutions maintain size, so no padding
        block.add_module("batch_norm2", nn.BatchNorm2d(bn_sz * growth_rate))
        block.add_module("relu2", nn.ReLU(inplace=True))
        block.add_module("conv2", nn.Conv2d(bn_sz*growth_rate, growth_rate, 3,
                                            stride=1, padding=1, bias=False))
        # 3x3 convs decrease size, so add padding =1 to maintain size

    def forward(self, *input):

        return X

class _DenseBlock(nn.Module):
    def __init__(self):
        return super().__init__()

    def forward(self, *input):
        return X


        
class _TransitionLayer(nn.Module):
    def __init__(self, n_in_features, n_out_features):
        super(_TransitionLayer, self).__init__()
        self.add_module('norm1', nn.BatchNorm2d(n_in_features))
        self.add_module('relu1', nn.ReLU(inplace=True))
        self.add_module('conv1', nn.Conv2d(n_in_features, n_out_features, 1,
                                           stride=1, bias=False))
        self.add_module('avg_pool', nn.AvgPool2d(kernel_size=2, stride=2))



class Dense169(nn.Module):
    def __init__(self):
        super(Dense169, self).__init__()

        self.network = nn.Sequential(
            nn.Conv2d(3, n_init_features, kernel_size=7, stride=2,
            padding=3, bias=True),
            nn.BatchNorm2d(n_init_features),
            nn.ReLU(inplace=True),
            nn.AvgPool2d(3, stride=2, padding=1)
        )

        for i, n_features in enumerate(block_config):
            self.network.add_module(

            )